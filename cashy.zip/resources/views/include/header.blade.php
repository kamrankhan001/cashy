<!-- Header -->
<header class="text-center p-4 bg-indigo-900 text-white">
    <h1 class="text-4xl font-bold uppercase">Cashy</h1>
</header>
