import 'flowbite';
