<?php $__env->startSection('title', 'Wallet'); ?>

<?php $__env->startSection('main'); ?>

    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="max-w-screen-lg mx-auto mb-28">
        <?php if(session('success')): ?>
            <div class="bg-green-500 text-white p-4 rounded-lg my-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Wallet Balance Section -->
        <div class="mt-6 mx-3">
            <h2 class="text-2xl font-bold mb-4">Wallet</h2>
            <p class="bg-yellow-500 text-white p-4 rounded-lg my-4">You can withdraw once amount in PKR is more then 200 rupees</p>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 text-center">
                <div class="bg-white border rounded-lg p-6 shadow-md">
                    <h2 class="text-2xl font-bold mb-4 capitalize">Earning</h2>
                    <p class="text-gray-800 text-3xl font-semibold mb-6"><?php echo e($user?->wallet?->amount); ?> Coins</p>
                </div>

                <div class="bg-white border rounded-lg p-6 shadow-md">
                    <h2 class="text-2xl font-bold mb-4 capitalize">Daily Earning</h2>
                    <p class="text-gray-800 text-3xl font-semibold mb-6"><?php echo e($user?->wallet?->daily_earning); ?> Coins</p>
                </div>

                <div class="bg-white border rounded-lg p-6 shadow-md">
                    <h2 class="text-2xl font-bold mb-4 capitalize">Earning in PKR</h2>
                    <p class="text-gray-800 text-3xl font-semibold mb-6">Rs <?php echo e($amount); ?></p>
                    <small class="text-gray-500">This price is after converting into PKR. 1 coin price is 0.2 PKR</small>
                </div>
            </div>
            <?php if($user->verified_deposit == 'verified'): ?>
                <div class="text-end my-3">
                    <button data-modal-target="exchangeModal" data-modal-toggle="exchangeModal"
                        class="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-300 transition duration-200">
                        Withdraw Now
                    </button>
                </div>
            <?php else: ?>
                <small class="text-red-600">You can withdraw this after verified.</small>
            <?php endif; ?>
        </div>

        <!-- Transaction History Section -->
        <div class="bg-white p-6 rounded-lg shadow-md mt-6 mx-3">
            <h2 class="text-2xl font-bold mb-4">Transaction History</h2>
            <div class="space-y-4">
                <!-- Loop through transactions (dummy data for now) -->
                <?php $__currentLoopData = $user->withDrawRequests()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withDrawRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="work-<?php echo e($withDrawRequest->id); ?>"
                        class="bg-gray-50 p-4 rounded-lg shadow-sm flex justify-between items-center">
                        <div>
                            <h3 class="text-lg font-semibold mb-1">Transaction on
                                <?php echo e($withDrawRequest->updated_at->format('M d, Y')); ?></h3>
                            <p class="text-gray-700">Time: <?php echo e($withDrawRequest->updated_at->format('H:i:s')); ?></p>
                            <p class="text-gray-700">Amount: <?php echo e($withDrawRequest->amount); ?> Coins</p>
                        </div>
                        <span
                            class="inline-block px-3 py-1 text-xs font-semibold text-white rounded-full <?php echo e($withDrawRequest->status == 'pending' ? 'bg-gray-400' : 'bg-green-500'); ?>">
                            <?php echo e($withDrawRequest->status); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Modal -->
        <div id="exchangeModal" tabindex="-1" aria-hidden="true" class="hidden fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="relative bg-white rounded-lg shadow-lg max-w-md w-full">
                    <!-- Modal Header -->
                    <div class="flex justify-between items-center p-5 border-b">
                        <h3 class="text-lg font-medium text-gray-900">
                            Convert Coins to PKR
                        </h3>
                        <button type="button" class="text-gray-400 hover:text-gray-500" data-modal-hide="exchangeModal">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <!-- Modal Body -->
                    <div class="p-6">
                        <form action="<?php echo e(route('request.withdraw', ['user' => $user->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label for="amount" class="block text-sm font-medium text-gray-700">Enter Amount
                                    (Coins)</label>
                                <input type="number" name="amount" id="amount" placeholder="Enter amount"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                                    required <?php if($amount < 200): ?> disabled <?php endif; ?>>
                            </div>
                            <p>PKR <?php echo e($amount); ?></p>
                            <!-- Submit Button -->
                            <div class="flex justify-end">
                                <?php if($amount >= 200): ?>
                                    <button type="submit"
                                        class="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-300 transition duration-200">
                                        Submit Request
                                    </button>
                                <?php else: ?>
                                    <p class="text-sm text-red-500">You have insufficient balance.</p>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kamran/aras/cashy/resources/views/wallet.blade.php ENDPATH**/ ?>