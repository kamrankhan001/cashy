<?php $__env->startSection('title', 'Initial Deposit'); ?>

<?php $__env->startSection('main'); ?>
    <div class="min-h-screen flex flex-col justify-center items-center bg-gradient-to-r from-purple-400 to-indigo-500 p-4">
        <div class="bg-white shadow-lg rounded-lg p-8 max-w-screen-md w-full text-center overflow-hidden">
            <h2 class="text-2xl font-bold mb-4">Please Deposit Your Initial Amount</h2>
            <p class="text-gray-700 mb-6">
                <span class="font-semibold">Note: Only JazzCash and Easypaisa are allowed</span>
            </p>

            <!-- Payment Method Images -->
            <div class="flex flex-wrap justify-around mb-6">
                <div class="flex flex-col items-center">
                    <img src="<?php echo e(asset('imgs/jazzcash.png')); ?>" alt="JazzCash" class="w-20 h-20 mb-2" />
                    <p>
                        <strong>Account Title:</strong> <?php echo e($settings->jazzcash_account_title); ?>

                    </p>
                    <p>
                        <strong>Account number:</strong> <?php echo e($settings->jazzcash_account_number); ?>

                    </p>
                    <p>
                        <strong>Bank Name:</strong> JazzCash
                    </p>
                </div>
                <div class="flex flex-col items-center mt-4 md:mt-0">
                    <img src="<?php echo e(asset('imgs/easypasa.jpeg')); ?>" alt="Easypaisa" class="w-20 h-20 mb-2" />
                    <p>
                        <strong>Account Title:</strong> <?php echo e($settings->easy_asa_account_title); ?>

                    </p>
                    <p>
                        <strong>Account number:</strong> <?php echo e($settings->easy_asa_account_number); ?>

                    </p>
                    <p>
                        <strong>Bank Name:</strong> EasyPaisa
                    </p>
                </div>
            </div>

            <p class="text-gray-700 mb-4">After sending this, please fill the following form:</p>

            <!-- Deposit Form -->
            <form action="<?php echo e(route('store.deposit')); ?>" method="POST" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>

                <div class="mb-4 text-start">
                    <label for="bank_name" class="block text-left text-gray-700">Bank Name</label>
                    <input type="text" id="bank_name" name="bank_name" placeholder="Enter your bank name" required
                        class="mt-1 p-3 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-600 <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('bank_name')); ?>">
                    <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 text-start">
                    <label for="account_name" class="block text-left text-gray-700">Account Name</label>
                    <input type="text" id="account_name" name="account_name" placeholder="Enter your account name"
                        required
                        class="mt-1 p-3 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-600 <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('account_name')); ?>">
                    <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 text-start">
                    <label for="account_number" class="block text-left text-gray-700">Account Number</label>
                    <input type="text" id="account_number" name="account_number" placeholder="Enter your account number"
                        required
                        class="mt-1 p-3 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-600 <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('account_number')); ?>">
                    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 text-start">
                    <label for="amount" class="block text-left text-gray-700">Deposit Amount</label>
                    <input type="text" id="amount" name="amount" placeholder="Enter your deposit amount" required
                        class="mt-1 p-3 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-600 <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount')); ?>">
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 text-start">
                    <label for="deposit_picture" class="block text-left text-gray-700">Deposit Picture</label>
                    <input type="file" id="deposit_picture" name="deposit_picture" accept="image/*" required
                        class="mt-1 p-3 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-indigo-600 <?php $__errorArgs = ['deposit_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['deposit_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="text-end">
                    <button type="submit"
                        class="bg-indigo-600 text-white py-2 px-6 rounded-lg hover:bg-indigo-500 transition duration-300">
                        Submit
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kamran/aras/cashy/resources/views/initial-deposit.blade.php ENDPATH**/ ?>